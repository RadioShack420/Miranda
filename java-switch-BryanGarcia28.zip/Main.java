import java.util.*;
class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("\033\143");
    System.out.println("Choose an activity?");
    System.out.println("1. Yes ");
    System.out.println("2. No ");
    int choice = input.nextInt();
    String blank = "";
    switch (choice){
      case 1:
        System.out.print("\033\143");
        System.out.println("Okay, what do you want to do?");
        System.out.println(blank);
        System.out.println("1. Eat");
        System.out.println("2. Shop");
        System.out.println("3. Sleep");
        System.out.println("4. Go To Cochella");
        int next = input.nextInt();
        switch (next){
          case 1:
            System.out.print("\033\143");
            System.out.println("You go to McDonalds, the drive was good..");
            input.nextLine();
            input.nextLine();
            System.out.println("You get there and see a special offer for something called Grimace's Brithday. It says something about a Grimace Shake or something..");
            input.nextLine();
            System.out.println("You decide to order one, and after a few minutes have your hands on a Grimace Shake..");
            input.nextLine();
            System.out.println("After a sip you feel funny, you start spouting things like 'Happy Birthday Grimace!' and decide to record a TikTok of you going to a small river..");
            input.nextLine();
            System.out.println("You float down the river spitting up some purple goo..");
            input.nextLine();
            System.out.println("Happy Brithday Grimace!");

          case 2:
            System.out.println("You decide to shop at Target, but suddenly a man throws part of the pride section to the ground, you decide it would be best to leave before you bear witness to more.");

          case 3:
            System.out.println("You hit the Z's..");
            Input.nextLine();
            System.out.println("Zzzzzzz.....");                             Input.nextLine();
            System.out.println("Suddenly you have a nightmare! Luckily, you woke up before you refused to give a dollar to charity infront of the cashier.");

          case 4:
             System.out.println("You get ready for Cochella shaking a Dunkin' Donuts coffee cup..");
            input.nextLine();
            System.out.println("While living your truth you see James Charles in fishnets talking to a few people..");
            input.nextLine();
            System.out.println("You want to leave after seeing that really bad, like realllll baddddd..");
            System.out.println("You wait to see if anyone with any actual importance shows up, but it never happens..");
            System.out.println("Before you head home you overhear James talking about wanting things straight, if its not straight then.. you're able to save your ears before it gets any worse.");
        }
        break;
      case 2:
        System.out.print("\033\143");
        System.out.print("Erm lets pretend you didn't say that!");
    }
  }
}
//System.out.println("");
//input.nextLine();