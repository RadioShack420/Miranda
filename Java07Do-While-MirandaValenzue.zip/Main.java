import java.util.*;
class Main{
  public static void main(String[] args) {
   boolean run = true;
   Random randomNumber = new Random();
   int num = 0 , iterations = 0;
   System.out.println( "You are entering level 1.");
   do{
       num = randomNumber .nextInt(100);
       if ( num > 50) {
           iterations++;
          System.out.println("Iterations = " + iterations);
        }
    } while (num > 50);
  }
}  