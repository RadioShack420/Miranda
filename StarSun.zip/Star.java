abstract class Star{
  public abstract void shine();

  public void twinkle(){
    System.out.println("The star is twinkling.");

  }
}