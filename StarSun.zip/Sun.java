class Sun extends Star{
  public void shine(){
    System.out.println("The sun is shining brightly.");
}
}    