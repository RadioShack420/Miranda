public class Main {
  public static void main(String[] args){
    Star star= new Sun();

    star.twinkle();
    star.shine();
  }
}