import java.util.*;
class Main {
  public static void main(String[] args) {
    int favnum = 0;
    System.out.println("What's your favorite number?");
    Scanner input = new Scanner(System.in);
    favnum = input.nextInt();
    if (favnum == 10){
      System.out.println("Good answer.");
    }
    else {
      System.out.println("Flop.");
    }
  }
}